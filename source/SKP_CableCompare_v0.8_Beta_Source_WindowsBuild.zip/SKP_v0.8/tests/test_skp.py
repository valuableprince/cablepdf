# -*- coding: utf-8 -*-
import os
import copy
import uuid
import sys
import json
import tempfile
import unittest
from pathlib import Path
from collections import Counter
from hashlib import sha256
import fitz
from openpyxl import load_workbook

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from skp_core import *
from skp_storage import save_session,load_session,revision_diff,history_dir
from skp_export import save_xlsx,highlight_pdf


def make_pdf(path, texts_by_page,rotation=0):
    with fitz.open() as pdf:
        for lines in texts_by_page:
            pg=pdf.new_page(width=850,height=600)
            for i,text in enumerate(lines):
                pg.insert_text((32,55+i*22),text,fontname='helv',fontsize=12)
            if rotation:pg.set_rotation(rotation)
        pdf.save(path)
    return path

class SKPCoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.dir=Path(self.tmp.name)
        self.flow=make_pdf(self.dir/'flow.pdf',[[
            'L1-42EM41A-SG01-WC01','L1-42EM41B-SG01-WC01',
            'L1-42EM41A-SG01-WC01']])
        self.pen=make_pdf(self.dir/'pen.pdf',[[
            '1.1.1 30/13-23 L1-42EM41A-SG01-WC01','1.1.2 40/23-34 L1-42EM41C-SG01-WC01']])
    def tearDown(self):self.tmp.cleanup()
    def session(self):return make_session(self.flow,self.pen)
    def test_01_two_text_pdfs_and_04_filter_module(self):
        s=self.session()
        self.assertEqual(len(s.flows.occurrences),3)
        self.assertEqual(len(s.penetrations.occurrences),2)
        self.assertFalse(any('30/13-23' in o.key for o in s.penetrations.occurrences))
    def test_02_scanned_pdf_rejected(self):
        scan=make_pdf(self.dir/'scan.pdf',[[]])
        with self.assertRaises(ValidationError):make_session(self.flow,scan)
    def test_03_partial_pages_not_false_missing(self):
        pen=make_pdf(self.dir/'pen_partial.pdf',[["L1-42EM41A-SG01-WC01"],[]])
        s=make_session(self.flow,pen)
        self.assertEqual(s.penetrations.unchecked_pages,[2])
        self.assertEqual(next(x.status for x in s.rows if 'EM41B' in x.key),'WR-03')
    def test_05_no_string_merging(self):
        pen=make_pdf(self.dir/'many.pdf',[["L1-42EM41A-SG01-WC01   L1-42EM41B-SG01-WC01"]])
        s=make_session(self.flow,pen)
        self.assertEqual(len(s.penetrations.occurrences),2)
    def test_06_rotated_page(self):
        p=make_pdf(self.dir/'rot.pdf',[["L1-42EM41A-SG01-WC01"]],rotation=90)
        d,_=analyze_pdf(p,'Потоки',Profile())
        self.assertEqual(len(d.occurrences),1)
        self.assertEqual(d.occurrences[0].page,1)
        self.assertEqual(len(d.occurrences[0].rect),4)
    def test_07_duplicates_grouped(self):
        s=self.session();self.assertEqual(next(r.flow_count for r in s.rows if 'EM41A' in r.key),2)
        self.assertEqual(len([r for r in s.rows if 'EM41A' in r.key]),1)
    def test_08_multiple_penetrations_allowed(self):
        s=self.session()
        o=next(o for o in s.penetrations.occurrences if 'EM41A' in o.key)
        apply_decision(s,o.id,'привязать','OBJECT-A\u219201')
        o2=copy.deepcopy(o);o2.id=uuid.uuid4().hex;o2.penetration_id='OBJECT-A\u219202'
        s.penetrations.occurrences.append(o2);s.recalc()
        self.assertNotIn('ER-03',[r.status for r in s.rows])
    def test_09_confirmed_link_conflict(self):
        s=self.session()
        for o in s.penetrations.occurrences:apply_decision(s,o.id,'привязать','BUILDING-A/LIST-01/POINT-05')
        self.assertEqual(Counter(x.status for x in s.rows)['ER-03'],2)
    def test_10_duplicate_number_unverified_no_conflict(self):
        s=self.session();self.assertEqual(Counter(x.status for x in s.rows)['ER-03'],0)
    def test_11_12_two_way(self):
        s=self.session();stats=Counter(x.status for x in s.rows)
        self.assertEqual(stats['OK-01'],1);self.assertEqual(stats['ER-01'],1);self.assertEqual(stats['ER-02'],1)
    def test_13_14_normalization_strict(self):
        self.assertEqual(normalize(' l1 – 42-EM41A-sg01-wc01 '),'L1-42-EM41A-SG01-WC01')
        self.assertNotEqual(normalize('A'),normalize('А'))
        self.assertNotEqual(normalize('WC01'),normalize('WC001'))
    def test_16_modes_identical(self):
        a=self.session();b=make_session(self.flow,self.pen,mode='Расширенная')
        self.assertEqual([(x.key,x.status) for x in a.rows],[(x.key,x.status) for x in b.rows])
    def test_17_manual_correction_and_original_preserved(self):
        original=sha256(self.pen.read_bytes()).hexdigest();s=self.session()
        o=next(o for o in s.penetrations.occurrences if 'EM41C' in o.key)
        apply_decision(s,o.id,'исправить','L1-42EM41B-SG01-WC01','опечатка')
        self.assertEqual(Counter(x.status for x in s.rows)['OK-01'],2)
        self.assertEqual(sha256(self.pen.read_bytes()).hexdigest(),original)
    def test_18_xlsx_three_sheets(self):
        s=self.session();path=self.dir/'report.xlsx';save_xlsx(s,path)
        wb=load_workbook(path)
        self.assertEqual(wb.sheetnames,['Сводка','Сверка кабелей','Замечания'])
        self.assertEqual(wb['Сверка кабелей'].max_row,len(s.rows)+1)
    def test_19_pdf_annotations(self):
        s=self.session();path=self.dir/'marked.pdf';count,fail=highlight_pdf(s,'Проходки',path)
        with fitz.open(path) as d:self.assertEqual(len(list(d[0].annots())),2)
        self.assertFalse(fail);self.assertEqual(sum(count.values()),2)
    def test_20_opt_in_save_open_pdf(self):
        os.environ['XDG_CONFIG_HOME']=str(self.dir/'prefs')
        s=self.session();name=save_session(s,copy_pdf=True)
        self.flow.unlink();self.pen.unlink()
        restored=load_session(name)
        self.assertEqual(len(restored.rows),3)
        self.assertTrue(Path(restored.flows.path).is_file())
    def test_21_revision_diff_page_movement(self):
        a=self.session()
        b=copy.deepcopy(a)
        b.flows.occurrences[0].page=15;b.recalc()
        report,warnings=revision_diff(a,b)
        self.assertTrue(all(x[1]=='Без изменений' for x in report))
    def test_pdf_content_but_no_matching_cables_not_false_error(self):
        pen=make_pdf(self.dir/'nomask.pdf',[["Table without cable markings", "30/13-23"]])
        s=make_session(self.flow,pen)
        self.assertTrue(all(row.status=='WR-03' for row in s.rows))
        self.assertTrue(any(issue.code=='WR-01' for issue in s.issues))

    def test_cyrillic_visual_twin_is_different(self):
        # Direct normalisation comparison; no silent transliteration.
        a='L1-42EM41B-XD5141B-WP01'
        b='L1-42EM41B-XD5141В-WP01'
        self.assertNotEqual(normalize(a),normalize(b))
        self.assertEqual(confusable_hint(b),a)

    def test_explicit_profile_rule_only_after_change(self):
        original='L1-42EM41B-XD5141В-WP01'
        self.assertNotEqual(normalize(original),normalize(confusable_hint(original)))
        p=Profile(replacements={'В':'B'})
        self.assertEqual(normalize(original,p),normalize(confusable_hint(original)))

    def test_pdf_original_sha_before_after_highlights(self):
        s=self.session()
        old=sha256(self.flow.read_bytes()).hexdigest()
        dest=self.dir/'marked-flows.pdf';highlight_pdf(s,'Потоки',dest)
        self.assertEqual(sha256(self.flow.read_bytes()).hexdigest(),old)
        with fitz.open(self.flow) as a,fitz.open(dest) as b:
            self.assertEqual(a[0].get_text(),b[0].get_text())

    def test_profile_json_roundtrip(self):
        p=Profile(name='objekt-10',patterns=[DEFAULT_PATTERN])
        dest=self.dir/'custom.json';p.save(dest)
        self.assertEqual(Profile.load(dest).patterns,p.patterns)

    def test_column_preservation_requires_original_occurrence(self):
        s=self.session()
        self.assertTrue(all(len(o.rect)==4 and o.raw for o in s.flows.occurrences))
        self.assertEqual({o.role for o in s.penetrations.occurrences},{'Проходки'})

    def test_userprofile_invalid(self):
        with self.assertRaises(ValidationError):Profile(patterns=['([A-Z]+)+']).validate()
    def test_csv_injection_not_formula(self):
        from skp_export import safe_cell
        self.assertTrue(safe_cell('=cmd|something').startswith("'"))
    def test_skipped_page(self):
        pen=make_pdf(self.dir/'mixed.pdf',[["L1-42EM41A-SG01-WC01"],[]])
        data,_=analyze_pdf(pen,'Проходки',Profile(),skip_pages={2})
        self.assertEqual(data.unchecked_pages,[]);self.assertEqual(data.skipped_pages,[2])


class SKPRealPDF(unittest.TestCase):
    def test_real_expected(self):
        root=Path(__file__).resolve().parents[2]
        # local development only; fixture files are not bundled in the source archive.
        flow=Path('/mnt/data/Контрольный список кабелей.pdf')
        pen=Path('/mnt/data/Кабели на проверку.pdf')
        if not flow.is_file() or not pen.is_file():self.skipTest('Real PDF fixtures not distributed')
        s=make_session(flow,pen)
        self.assertEqual(len(s.flows.occurrences),181)
        self.assertEqual(len(s.penetrations.occurrences),142)
        self.assertEqual(Counter(x.status for x in s.rows),Counter({'OK-01':122,'ER-01':59,'ER-02':20}))
        self.assertEqual(len(s.issues),10)

if __name__=='__main__':
    import copy,uuid
    unittest.main()
