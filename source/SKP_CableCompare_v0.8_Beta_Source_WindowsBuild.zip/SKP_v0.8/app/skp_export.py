# -*- coding: utf-8 -*-
"""Three-sheet XLSX reports and precise, non-destructive PDF highlights/comments."""
from collections import Counter
from pathlib import Path
from datetime import datetime
import os
import math
import tempfile

import fitz
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from skp_core import Session,ValidationError

STATUS_COLOR={'OK-01':'E1F3E7','ER-01':'FCE4E4','ER-02':'FCE4E4','ER-03':'F9CDD0',
              'WR-01':'FFF1CB','WR-02':'FFF1CB','WR-03':'FFF1CB'}
PDF_COLOR={'OK-01':(0.31,0.76,0.43),'ER-01':(0.97,0.37,0.41),'ER-02':(0.97,0.37,0.41),
           'ER-03':(0.97,0.37,0.41),'WR-03':(1.0,0.8,0.2)}


def safe_cell(value):
    s=str(value) if value is not None else ''
    # Avoid spreadsheet formula injection from user-controlled PDF strings.
    return "'"+s if s.startswith(('=','+','-','@')) else s


def save_xlsx(session:Session,dest:Path):
    dest=Path(dest)
    if dest.exists():raise ValidationError(f'Файл уже существует: {dest}')
    wb=Workbook();summary=wb.active;summary.title='Сводка'
    report=wb.create_sheet('Сверка кабелей');warnings=wb.create_sheet('Замечания')
    summary.append(['СКП — СВОДКА РЕЗУЛЬТАТОВ',''])
    stats=Counter(r.status for r in session.rows)
    info=[('Версия приложения','0.8.0-beta'),('Сеанс',session.sid),('Время',session.created),
          ('Проект',session.project),('Профиль',session.profile.name+' '+session.profile.version),
          ('Режим',session.mode),('PDF потоков',session.flows.filename),('Ревизия потоков',session.flow_revision),
          ('SHA-256 потоков',session.flows.digest),('Страниц потоков',session.flows.page_count),
          ('Проверены (потоки)',', '.join(map(str,session.flows.checked_pages))),
          ('Не проверены (потоки)',', '.join(map(str,session.flows.unchecked_pages))),
          ('PDF проходок',session.penetrations.filename),('Ревизия проходок',session.penetration_revision),
          ('SHA-256 проходок',session.penetrations.digest),('Страниц проходок',session.penetrations.page_count),
          ('Проверены (проходки)',', '.join(map(str,session.penetrations.checked_pages))),
          ('Не проверены (проходки)',', '.join(map(str,session.penetrations.unchecked_pages))),
          ('Кабелей в потоках',len(set(o.key for o in session.flows.occurrences if not o.excluded))),
          ('Кабелей в проходках',len(set(o.key for o in session.penetrations.occurrences if not o.excluded))),
          ('Уникальных кабелей (объединение)',len(session.rows)),
          ('Совпадений (OK-01)',stats['OK-01']),('Отсутствуют в проходках (ER-01)',stats['ER-01']),
          ('Только в проходках (ER-02)',stats['ER-02']),('Конфликты привязки (ER-03)',stats['ER-03']),
          ('Неполные проверки (WR-03)',stats['WR-03']),('Замечаний извлечения',len(session.issues)),
          ('Ручных решений',len(session.decisions))]
    for label,val in info:summary.append([label,safe_cell(val)])
    summary.column_dimensions['A'].width=42;summary.column_dimensions['B'].width=100
    report.append(['№','Обозначение кабеля','Статус','Стр. потоков','Стр. проходок',
                   'Упоминаний в потоках','Упоминаний в проходках',
                   'Подтверждённые проходки','Статус привязки','Примечание'])
    for i,r in enumerate(session.rows,1):
        report.append([i,safe_cell(r.key),r.status,r.flow_pages,r.penetration_pages,
                       r.flow_count,r.penetration_count,safe_cell(r.assignments),r.link_quality,r.note])
        fill=PatternFill('solid',fgColor=STATUS_COLOR.get(r.status,'FFFFFF'))
        for cell in report[report.max_row]:cell.fill=fill
    warnings.append(['Код','Источник','Страница','Обозначение / фрагмент','Описание'])
    for issue in session.issues:
        warnings.append([issue.code,issue.role,issue.page,safe_cell(issue.text),issue.details])
    for decision in session.decisions:
        warnings.append(['РЕШЕНИЕ',decision.get('action',''),'',
                         safe_cell(decision.get('occurrence_id','')),decision.get('comment','')])
    for sheet in (report,warnings):
        sheet.freeze_panes='A2';sheet.auto_filter.ref=sheet.dimensions
        sheet.sheet_view.showGridLines=False
        for cell in sheet[1]:
            cell.font=Font(color='FFFFFF',bold=True);cell.fill=PatternFill('solid',fgColor='183850')
            cell.alignment=Alignment(vertical='center',wrap_text=True)
        sheet.row_dimensions[1].height=34
    for col,width in enumerate([7,39,17,17,17,20,21,33,35,78],1):
        report.column_dimensions[get_column_letter(col)].width=width
    for col,width in enumerate([17,23,12,53,75],1):warnings.column_dimensions[get_column_letter(col)].width=width
    summary['A1'].font=Font(size=14,bold=True,color='183850')
    dest.parent.mkdir(parents=True,exist_ok=True)
    tmp=dest.with_name('~'+dest.name)
    try:wb.save(tmp);tmp.replace(dest)
    finally:tmp.unlink(missing_ok=True)
    return dest


def highlight_pdf(session:Session,role:str,dest:Path,strict=True):
    """Highlights only exact per-char rectangles from extracted text. No approximate text search."""
    d=session.flows if role=='Потоки' else session.penetrations
    src=Path(d.path);dest=Path(dest)
    if not src.is_file():raise ValidationError('Исходный PDF недоступен (возможно, сеанс загружен без копий)')
    if src.resolve()==dest.resolve():raise ValidationError('Нельзя перезаписать исходный PDF')
    if dest.exists():raise ValidationError(f'Файл уже существует: {dest}')
    lookup={r.key:r for r in session.rows}
    count=Counter();fail=[]
    doc=fitz.open(src)
    with doc:
        for o in d.occurrences:
            if o.excluded:continue
            row=lookup.get(o.key)
            if row is None:continue
            code=row.status
            if code not in PDF_COLOR:continue
            try:
                page=doc[o.page-1]
                rect=fitz.Rect(o.rect)
                if not all(math.isfinite(v) for v in o.rect) or rect.is_empty or not page.cropbox.contains(rect):
                    raise ValueError('Координаты вне страницы')
                # Page gets a highlight annotation exactly over the original text bbox.
                annotation=page.add_highlight_annot(rect)
                if annotation is None:raise ValueError('Невозможно создать аннотацию')
                annotation.set_colors(stroke=PDF_COLOR[code]); annotation.set_opacity(0.38)
                annotation.set_info(title='СКП — сверка кабелей',subject=code,
                    content=f'{o.raw}\n{code} — {row.note}\nЛист: {o.page}\nИсточник: {role}')
                annotation.update()
                count[code]+=1
            except (ValueError,RuntimeError,IndexError) as exc:
                fail.append((o.page,o.raw,str(exc)))
        # Reject an incomplete export rather than falsely imply all positions were marked.
        if strict and fail:
            raise ValidationError(f'Нет точной подсветки для {len(fail)} позиций. Пример: {fail[0]}')
        dest.parent.mkdir(parents=True,exist_ok=True)
        doc.save(dest,garbage=3,deflate=True)
    return count,fail
