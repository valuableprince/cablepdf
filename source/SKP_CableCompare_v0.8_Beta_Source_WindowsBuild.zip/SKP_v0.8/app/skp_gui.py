# -*- coding: utf-8 -*-
"""СКП — desktop engineering checker. Tk/ttk, non-blocking processing, no network."""
from __future__ import annotations
import copy
import json
import os
import queue
import shutil
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from datetime import datetime
from pathlib import Path
from collections import Counter

from skp_core import (VERSION,Profile,ValidationError,Cancelled,make_session,
                      apply_decision,revision_diff,normalize)
from skp_storage import (read_settings,write_settings,profile_dir,list_profiles,
                         save_session,list_sessions,load_session)
from skp_export import save_xlsx,highlight_pdf
from skp_viewer import PDFViewer

HEADERS={
    'n':('№',52),'key':('Обозначение кабеля',345),'status':('Статус',95),
    'assignments':('Проходка(и)',190),'link':('Привязка',215),
    'flow':('Стр. потоков',100),'pen':('Стр. проходок',110),
    'na':('В потоках',95),'nb':('В проходках',105),'note':('Примечание',455),
}
COLUMNS=list(HEADERS)
STATUS_DESCR={'OK-01':'Совпадает','ER-01':'Нет в проходках','ER-02':'Нет в потоках',
              'ER-03':'Конфликт','WR-01':'Распознавание','WR-02':'Привязка','WR-03':'Неполнота'}

class SKPApp:
    def __init__(self,root:tk.Tk):
        self.root=root
        self.root.title('СКП • Сверка кабелей и проходок — '+VERSION)
        self.root.geometry('1430x860');self.root.minsize(920,600)
        self.settings=read_settings()
        if self.settings.get('geometry'):
            try:self.root.geometry(self.settings['geometry'])
            except tk.TclError:pass
        self.session=None
        self.viewer=None
        self.worker=None
        self.events=queue.Queue();self.cancel_event=threading.Event()
        self.profile=Profile()
        self.profile_path=None
        self.flow_var=tk.StringVar(value=self.settings.get('flow',''))
        self.pen_var=tk.StringVar(value=self.settings.get('pen',''))
        self.flow_info=tk.StringVar(value='')
        self.pen_info=tk.StringVar(value='')
        self.project_var=tk.StringVar(value=self.settings.get('project',''))
        self.flow_rev_var=tk.StringVar(value='')
        self.pen_rev_var=tk.StringVar(value='')
        self.mode_var=tk.StringVar(value='Быстрая')
        self.profile_var=tk.StringVar(value='Стандартный')
        self.filter_var=tk.StringVar(value='Все статусы')
        self.search_var=tk.StringVar(value='')
        self.summary_var=tk.StringVar(value='Выберите два текстовых PDF. OCR не используется.')
        self.progress_var=tk.DoubleVar(value=0)
        self.skip_flow=tk.StringVar(value='')
        self.skip_pen=tk.StringVar(value='')
        self.show_hidden=self.settings.get('columns',COLUMNS[:])
        self.order=sorted(COLUMNS,key=lambda key:self.show_hidden.index(key) if key in self.show_hidden else 99)
        self._build()
        self._load_profile()
        self.root.protocol('WM_DELETE_WINDOW',self.on_close)
        self.root.after(120,self.poll_events)

    def _build(self):
        style=ttk.Style(self.root)
        try:style.theme_use('clam')
        except tk.TclError:pass
        style.configure('Title.TLabel',font=('Segoe UI',17,'bold'),foreground='#183850')
        style.configure('Sub.TLabel',font=('Segoe UI',9),foreground='#596c7b')
        style.configure('Treeview',rowheight=26,font=('Segoe UI',10))
        style.configure('Treeview.Heading',font=('Segoe UI',9,'bold'))
        self._make_menu()
        root=self.root;root.columnconfigure(0,weight=1);root.rowconfigure(3,weight=1)
        hdr=ttk.Frame(root,padding=(15,8,15,4));hdr.grid(row=0,column=0,sticky='ew')
        ttk.Label(hdr,text='Сверка кабелей и проходок',style='Title.TLabel').pack(anchor='w')
        ttk.Label(hdr,text='Только PDF с текстовым слоем  •  Локальная проверка  •  Точные совпадения без подмены букв',
                  style='Sub.TLabel').pack(anchor='w')
        sources=ttk.LabelFrame(root,text='Исходные PDF',padding=9)
        sources.grid(row=1,column=0,sticky='ew',padx=14,pady=(0,6));sources.columnconfigure(1,weight=1)
        for row,label,var,info in [(0,'Кабельные потоки / контрольный перечень',self.flow_var,self.flow_info),
                                   (1,'Кабельные проходки',self.pen_var,self.pen_info)]:
            ttk.Label(sources,text=label,width=44).grid(row=row,column=0,sticky='w',pady=4)
            ttk.Entry(sources,textvariable=var).grid(row=row,column=1,sticky='ew',pady=4)
            ttk.Button(sources,text='Выбрать PDF…',command=lambda v=var,inf=info:self.choose_pdf(v,inf)).grid(row=row,column=2,padx=7)
            ttk.Label(sources,textvariable=info,style='Sub.TLabel',width=20).grid(row=row,column=3,padx=(2,0),sticky='w')
        params=ttk.Frame(sources);params.grid(row=2,column=0,columnspan=3,sticky='ew',pady=6)
        for label,var,width in [('Проект',self.project_var,25),('Ревизия потоков',self.flow_rev_var,13),
                                 ('Ревизия проходок',self.pen_rev_var,13)]:
            ttk.Label(params,text=label).pack(side='left',padx=(7,4))
            ttk.Entry(params,textvariable=var,width=width).pack(side='left',padx=(0,10))
        ttk.Label(params,text='Режим').pack(side='left',padx=(7,4))
        ttk.Combobox(params,textvariable=self.mode_var,values=['Быстрая','Расширенная'],
                     state='readonly',width=14).pack(side='left')
        bar=ttk.Frame(root,padding=(14,2,14,8));bar.grid(row=2,column=0,sticky='ew')
        self.run_button=ttk.Button(bar,text='▶  Выполнить сверку',command=self.begin)
        self.run_button.pack(side='left',padx=(0,5))
        self.cancel_btn=ttk.Button(bar,text='Отмена',command=self.stop,state='disabled')
        self.cancel_btn.pack(side='left',padx=(0,14))
        ttk.Label(bar,text='Профиль:').pack(side='left')
        self.profile_combo=ttk.Combobox(bar,textvariable=self.profile_var,values=['Стандартный'],width=20,state='readonly')
        self.profile_combo.pack(side='left',padx=5)
        self.profile_combo.bind('<<ComboboxSelected>>',lambda e:self._load_profile())
        ttk.Button(bar,text='Настроить…',command=self.edit_profile).pack(side='left',padx=(0,12))
        ttk.Button(bar,text='Экспорт…',command=self.export_dialog).pack(side='left',padx=(0,5))
        ttk.Button(bar,text='Сохранить сеанс',command=self.save_session_dialog).pack(side='left',padx=(0,5))
        self.progress=ttk.Progressbar(bar,mode='determinate',variable=self.progress_var,maximum=100,length=155)
        self.progress.pack(side='right',padx=(10,0))
        body=ttk.LabelFrame(root,text='Результаты',padding=6)
        body.grid(row=3,column=0,sticky='nsew',padx=14,pady=(0,5))
        body.columnconfigure(0,weight=1);body.rowconfigure(1,weight=1)
        search=ttk.Frame(body);search.grid(row=0,column=0,sticky='ew',pady=(0,5))
        ttk.Label(search,text='Поиск по кабелю / проходке:').pack(side='left')
        ttk.Entry(search,textvariable=self.search_var,width=35).pack(side='left',padx=6)
        self.search_var.trace_add('write',lambda *_:self.fill())
        ttk.Label(search,text='Фильтр:').pack(side='left',padx=(14,4))
        combo=ttk.Combobox(search,textvariable=self.filter_var,state='readonly',width=22,
            values=['Все статусы','Несоответствия','OK-01','ER-01','ER-02','ER-03','WR-03'])
        combo.pack(side='left');combo.bind('<<ComboboxSelected>>',lambda _:self.fill())
        ttk.Button(search,text='Столбцы…',command=self.configure_columns).pack(side='right')
        table=ttk.Frame(body);table.grid(row=1,column=0,sticky='nsew');table.rowconfigure(0,weight=1);table.columnconfigure(0,weight=1)
        self.tree=ttk.Treeview(table,columns=COLUMNS,show='headings',selectmode='browse')
        for k,(title,w) in HEADERS.items():
            self.tree.heading(k,text=title,command=lambda c=k:self.sort_column(c))
            self.tree.column(k,width=int(self.settings.get('widths',{}).get(k,w)),stretch=k in ('key','note'))
        self.tree.configure(displaycolumns=self.show_hidden)
        for tag,color in [('OK-01','#e5f4e9'),('ER-01','#fee5e5'),('ER-02','#fee5e5'),
                          ('ER-03','#ffd5d9'),('WR-03','#fff0c7')]:self.tree.tag_configure(tag,background=color)
        self.tree.grid(row=0,column=0,sticky='nsew')
        y=ttk.Scrollbar(table,orient='vertical',command=self.tree.yview);y.grid(row=0,column=1,sticky='ns')
        x=ttk.Scrollbar(table,orient='horizontal',command=self.tree.xview);x.grid(row=1,column=0,sticky='ew')
        self.tree.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        self.tree.bind('<Double-1>',lambda _:self.open_selected())
        self.tree.bind('<Button-3>',self.context_menu)
        foot=ttk.Frame(root,padding=(14,0,14,9));foot.grid(row=4,column=0,sticky='ew')
        ttk.Label(foot,textvariable=self.summary_var,wraplength=1400).pack(anchor='w')
        ttk.Label(foot,text='Указание кабеля в двух документах не доказывает правильность физической проходки. '
                  'Непроверенные страницы выделяются предупреждением.',style='Sub.TLabel').pack(anchor='w',pady=(3,0))

    def _make_menu(self):
        m=tk.Menu(self.root);self.root.config(menu=m)
        file=tk.Menu(m,tearoff=False)
        file.add_command(label='Новая сверка',command=self.reset)
        file.add_command(label='Экспорт…',command=self.export_dialog)
        file.add_command(label='Сохранить сеанс…',command=self.save_session_dialog)
        file.add_separator();file.add_command(label='Выход',command=self.on_close)
        m.add_cascade(label='Новая сверка',menu=file)
        res=tk.Menu(m,tearoff=False)
        res.add_command(label='Просмотр исходного PDF',command=self.open_selected)
        res.add_command(label='Ручная проверка / исправление',command=self.edit_selected)
        res.add_command(label='Настроить столбцы',command=self.configure_columns)
        m.add_cascade(label='Результаты',menu=res)
        j=tk.Menu(m,tearoff=False);j.add_command(label='Журнал проверки',command=self.open_journal)
        m.add_cascade(label='Журнал',menu=j)
        p=tk.Menu(m,tearoff=False)
        p.add_command(label='Редактировать профиль',command=self.edit_profile)
        p.add_command(label='Импорт профиля JSON',command=self.import_profile)
        p.add_command(label='Экспорт профиля JSON',command=self.export_profile)
        m.add_cascade(label='Профили',menu=p)
        h=tk.Menu(m,tearoff=False);h.add_command(label='История сеансов',command=self.open_history)
        m.add_cascade(label='История',menu=h)
        options=tk.Menu(m,tearoff=False)
        options.add_command(label='Исключить титульные / пустые страницы…',command=self.skip_dialog)
        options.add_command(label='О программе',command=lambda:messagebox.showinfo('СКП',
            'Версия '+VERSION+'\nПредварительная реализация ТЗ 1.0.\nPDF только с извлекаемым текстом. OCR отсутствует.'))
        m.add_cascade(label='Настройки',menu=options)

    def choose_pdf(self,var,info=None):
        f=filedialog.askopenfilename(title='Выберите текстовый PDF',filetypes=[('PDF файлы','*.pdf')])
        if f:
            var.set(f)
            if info is not None:
                try:
                    import fitz
                    with fitz.open(f) as pdf: info.set(f'{pdf.page_count} стр. • доступен')
                except Exception as exc: info.set('Ошибка PDF')

    def _parse_pages(self,text):
        result=set()
        if not text.strip():return result
        for part in text.split(','):
            part=part.strip()
            if '-' in part:
                a,b=map(int,part.split('-',1))
                if b<a or b-a>500:raise ValueError('Некорректный диапазон')
                result.update(range(a,b+1))
            else:result.add(int(part))
        if min(result,default=1)<1:raise ValueError('Номера страниц начинаются с 1')
        return result

    def skip_dialog(self):
        dlg=tk.Toplevel(self.root);dlg.title('Исключение страниц');dlg.transient(self.root)
        ttk.Label(dlg,text='Исключения задаются номерами страниц, например: 1, 3-5.\n'
            'Исключённые страницы не считаются непроверенными, их содержимое не анализируется.',
            padding=10).pack(anchor='w')
        for label,var in [('Потоки',self.skip_flow),('Проходки',self.skip_pen)]:
            fr=ttk.Frame(dlg,padding=(10,5));fr.pack(fill='x')
            ttk.Label(fr,text=label,width=12).pack(side='left')
            ttk.Entry(fr,textvariable=var,width=28).pack(side='left')
        ttk.Button(dlg,text='Готово',command=dlg.destroy).pack(pady=10)

    def begin(self):
        if self.worker and self.worker.is_alive():return
        if not self.flow_var.get() or not self.pen_var.get():
            messagebox.showwarning('Нет PDF','Укажите два PDF',parent=self.root);return
        try:skip_a=self._parse_pages(self.skip_flow.get());skip_b=self._parse_pages(self.skip_pen.get())
        except (ValueError,TypeError) as exc:
            messagebox.showerror('Страницы',str(exc));return
        self.cancel_event.clear();self.progress_var.set(0)
        self.run_button.configure(state='disabled');self.cancel_btn.configure(state='normal')
        self.summary_var.set('Проверка исходных PDF…')
        data=(Path(self.flow_var.get()),Path(self.pen_var.get()),copy.deepcopy(self.profile),
              self.mode_var.get(),self.project_var.get(),self.flow_rev_var.get(),self.pen_rev_var.get(),skip_a,skip_b)
        def worker():
            try:
                def progress(role,idx,total):self.events.put(('progress',f'{role}: лист {idx} из {total}',idx,total,role))
                session=make_session(*data[:2],profile=data[2],mode=data[3],project=data[4],
                    flow_revision=data[5],penetration_revision=data[6],skip_flow=data[7],
                    skip_penetrations=data[8],progress=progress,cancelled=self.cancel_event.is_set)
                self.events.put(('done',session))
            except Cancelled:self.events.put(('cancel',))
            except Exception as exc:self.events.put(('error',str(exc)))
        self.worker=threading.Thread(target=worker,name='SKPExtract',daemon=True);self.worker.start()

    def poll_events(self):
        try:
            while True:
                e=self.events.get_nowait()
                if e[0]=='progress':
                    self.summary_var.set('Извлечение: '+e[1])
                    val=(e[2]/max(1,e[3]))*50+(0 if e[4]=='Потоки' else 50)
                    self.progress_var.set(val)
                elif e[0]=='done':
                    self.session=e[1];self.progress_var.set(100);self.run_button.config(state='normal')
                    self.cancel_btn.config(state='disabled');self.fill()
                    if self.session.mode=='Расширенная':self.open_journal()
                elif e[0] in ('error','cancel'):
                    self.run_button.config(state='normal');self.cancel_btn.config(state='disabled')
                    if e[0]=='error':messagebox.showerror('Сверка не завершена',e[1]);self.summary_var.set('Ошибка: '+e[1])
                    else:self.summary_var.set('Операция отменена. Результат не заменён.')
        except queue.Empty:pass
        self.root.after(120,self.poll_events)

    def stop(self):self.cancel_event.set();self.summary_var.set('Отмена…')

    def _all_rows(self):return self.session.rows if self.session else []

    def fill(self):
        self.tree.delete(*self.tree.get_children())
        if not self.session:return
        text=self.search_var.get().strip().casefold();f=self.filter_var.get()
        for i,r in enumerate(self.session.rows,1):
            if text and text not in (r.key+' '+r.assignments).casefold():continue
            if f=='Несоответствия' and r.status=='OK-01':continue
            if f not in ('Все статусы','Несоответствия') and r.status!=f:continue
            values=(i,r.key,r.status,r.assignments,r.link_quality,r.flow_pages,
                    r.penetration_pages,r.flow_count,r.penetration_count,r.note)
            self.tree.insert('', 'end',iid=r.key,values=values,tags=(r.status,))
        counts=Counter(x.status for x in self.session.rows)
        self.summary_var.set(f"Потоки: {len(set(x.key for x in self.session.flows.occurrences if not x.excluded))}  |  "
            f"Проходки: {len(set(x.key for x in self.session.penetrations.occurrences if not x.excluded))}  |  "
            f"OK: {counts['OK-01']}  |  ER-01: {counts['ER-01']}  |  ER-02: {counts['ER-02']}  |  "
            f"ER-03: {counts['ER-03']}  |  WR-03: {counts['WR-03']}  |  "
            f"WR-01: {len(self.session.issues)}  |  всего {len(self.session.rows)}")

    def sort_column(self,col):
        items=self.tree.get_children('');old=getattr(self,'sort_state',None)
        reverse=bool(old and old[0]==col and not old[1]);self.sort_state=(col,reverse)
        def key(item):
            v=self.tree.set(item,col)
            return int(v) if col in ('n','na','nb') and v.isdigit() else v.casefold()
        for index,item in enumerate(sorted(items,key=key,reverse=reverse)):
            self.tree.move(item,'',index)

    def selected_row(self):
        if not self.session:return None
        selection=self.tree.selection()
        if not selection:return None
        return next((r for r in self.session.rows if r.key==selection[0]),None)

    def context_menu(self,event):
        row=self.tree.identify_row(event.y)
        if not row:return
        self.tree.selection_set(row)
        menu=tk.Menu(self.root,tearoff=False)
        menu.add_command(label='Открыть PDF на кабеле',command=self.open_selected)
        menu.add_command(label='Ручная проверка / исправить',command=self.edit_selected)
        menu.add_command(label='Копировать обозначение',command=self.copy_selected)
        menu.tk_popup(event.x_root,event.y_root)

    def copy_selected(self):
        row=self.selected_row()
        if row:self.root.clipboard_clear();self.root.clipboard_append(row.key)

    def open_selected(self):
        row=self.selected_row()
        if not row:return
        for role,doc in [('Потоки',self.session.flows),('Проходки',self.session.penetrations)]:
            matches=[o for o in doc.occurrences if o.key==row.key and not o.excluded]
            if not matches:continue
            if self.viewer is None or not self.viewer.winfo_exists():
                self.viewer=PDFViewer(self.root,self.session,role,matches[0])
            else:self.viewer.session=self.session;self.viewer.jump_to(role,matches[0])
            self.viewer.lift();return
        messagebox.showwarning('PDF','Нет доступного исходного упоминания для этой строки')

    def edit_selected(self):
        row=self.selected_row()
        if not row:return
        occ=[o for d in (self.session.flows,self.session.penetrations) for o in d.occurrences if o.key==row.key]
        if not occ:return
        dlg=tk.Toplevel(self.root);dlg.title('Журнал ручной проверки — '+row.key)
        dlg.geometry('1100x440');dlg.transient(self.root)
        ttk.Label(dlg,text='Выберите исходное упоминание. Исправление применяется только к текущему сеансу.',
                  padding=10).pack(anchor='w')
        tbl=ttk.Treeview(dlg,columns=['role','page','raw','status','link'],show='headings')
        for c,label,w in [('role','PDF',130),('page','Лист',65),('raw','Исходная маркировка',440),
                          ('status','Состояние',140),('link','Проходка',240)]:
            tbl.heading(c,text=label);tbl.column(c,width=w)
        tbl.pack(fill='both',expand=True,padx=10)
        for o in occ:tbl.insert('','end',iid=o.id,values=(o.role,o.page,o.raw,
            'Исключено' if o.excluded else 'Активно',o.penetration_id))
        controls=ttk.Frame(dlg,padding=10);controls.pack(fill='x')
        ttk.Label(controls,text='Значение / ID проходки:').grid(row=0,column=0)
        newvar=tk.StringVar(value=row.key);ttk.Entry(controls,textvariable=newvar,width=55).grid(row=0,column=1,padx=5)
        ttk.Label(controls,text='Комментарий:').grid(row=1,column=0,pady=6)
        comment=tk.StringVar();ttk.Entry(controls,textvariable=comment,width=55).grid(row=1,column=1,padx=5)
        def apply(action):
            sel=tbl.selection()
            if not sel:messagebox.showwarning('Упоминание','Выберите строку',parent=dlg);return
            try:apply_decision(self.session,sel[0],action,newvar.get(),comment.get())
            except Exception as exc:messagebox.showerror('Решение',str(exc),parent=dlg);return
            dlg.destroy();self.fill()
        buttons=ttk.Frame(dlg,padding=8);buttons.pack()
        for label,action in [('Подтвердить','подтвердить'),('Исправить','исправить'),
                             ('Исключить ложное','исключить'),('Привязать проходку','привязать'),
                             ('Снять привязку','снять привязку')]:
            ttk.Button(buttons,text=label,command=lambda a=action:apply(a)).pack(side='left',padx=3)

    def open_journal(self):
        if not self.session:messagebox.showinfo('Журнал','Сначала выполните сверку');return
        dlg=tk.Toplevel(self.root);dlg.title('Журнал проверки и диагностики')
        dlg.geometry('1150x600')
        table=ttk.Treeview(dlg,columns=['code','role','page','value','detail'],show='headings')
        for k,title,width in [('code','Код',95),('role','PDF',115),('page','Страница',80),
                              ('value','Фрагмент',370),('detail','Причина',480)]:
            table.heading(k,text=title);table.column(k,width=width)
        table.pack(fill='both',expand=True,padx=10,pady=10)
        for i,x in enumerate(self.session.issues):
            table.insert('','end',iid=f'i{i}',values=(x.code,x.role,x.page,x.text,x.details))
        for i,x in enumerate(self.session.decisions):
            table.insert('','end',iid=f'd{i}',values=('РЕШЕНИЕ',x['action'],'',x['occurrence_id'],
                                                       x.get('comment','')+' '+x['timestamp']))
        ttk.Label(dlg,text='WR-01 — не объединяется с совпадениями автоматически; ручные решения доступны через таблицу результатов.',
                  padding=9).pack(anchor='w')

    def configure_columns(self):
        dlg=tk.Toplevel(self.root);dlg.title('Столбцы');dlg.transient(self.root)
        ttk.Label(dlg,text='Отметьте нужные столбцы и задайте порядок через стрелки.',padding=10).pack()
        box=tk.Listbox(dlg,height=len(COLUMNS),width=45,selectmode='browse');box.pack(padx=10)
        selections={k:tk.BooleanVar(value=k in self.show_hidden) for k in COLUMNS}
        for k in self.order:box.insert('end',('☑ ' if selections[k].get() else '☐ ')+HEADERS[k][0])
        def refresh():
            sel=box.curselection();box.delete(0,'end')
            for k in self.order:box.insert('end',('☑ ' if selections[k].get() else '☐ ')+HEADERS[k][0])
            if sel:box.selection_set(sel[0])
        def toggle():
            sel=box.curselection()
            if sel: k=self.order[sel[0]];selections[k].set(not selections[k].get());refresh()
        def move(direction):
            sel=box.curselection()
            if not sel:return
            i=sel[0];j=i+direction
            if j<0 or j>=len(self.order):return
            self.order[i],self.order[j]=self.order[j],self.order[i]
            refresh();box.selection_clear(0,'end');box.selection_set(j)
        box.bind('<Double-1>',lambda _:toggle())
        row=ttk.Frame(dlg);row.pack(pady=8)
        ttk.Button(row,text='Показать / скрыть',command=toggle).pack(side='left',padx=3)
        ttk.Button(row,text='↑',command=lambda:move(-1)).pack(side='left',padx=3)
        ttk.Button(row,text='↓',command=lambda:move(1)).pack(side='left',padx=3)
        def save():
            self.show_hidden=[k for k in self.order if selections[k].get()]
            if not self.show_hidden:self.show_hidden=['key'];
            self.tree.configure(displaycolumns=self.show_hidden);dlg.destroy()
        ttk.Button(dlg,text='Сохранить',command=save).pack(pady=8)

    def _refresh_profiles(self):
        names=['Стандартный']+[p.stem for p in list_profiles()]
        self.profile_combo.configure(values=names)
        if self.profile_var.get() not in names:self.profile_var.set('Стандартный')

    def _load_profile(self):
        self._refresh_profiles()
        name=self.profile_var.get()
        if name=='Стандартный':self.profile=Profile();self.profile_path=None;return
        path=profile_dir()/(name+'.json')
        try:self.profile=Profile.load(path);self.profile_path=path
        except Exception as exc:
            messagebox.showerror('Профиль',str(exc));self.profile=Profile();self.profile_var.set('Стандартный')

    def edit_profile(self):
        p=copy.deepcopy(self.profile)
        dlg=tk.Toplevel(self.root);dlg.title('Профиль распознавания');dlg.geometry('830x680');dlg.transient(self.root)
        ttk.Label(dlg,text='Профиль проекта. Тексты без подходящей маски не считаются кабелями.',padding=10).pack(anchor='w')
        line=ttk.Frame(dlg,padding=8);line.pack(fill='x')
        name=tk.StringVar(value=p.name);version=tk.StringVar(value=p.version)
        ttk.Label(line,text='Имя:').pack(side='left');ttk.Entry(line,textvariable=name,width=29).pack(side='left',padx=6)
        ttk.Label(line,text='Версия:').pack(side='left');ttk.Entry(line,textvariable=version,width=10).pack(side='left',padx=6)
        ttk.Label(dlg,text='Регулярные выражения кабелей (по одному на строку)',padding=(10,6)).pack(anchor='w')
        patterns=tk.Text(dlg,height=6);patterns.pack(fill='x',padx=10)
        patterns.insert('1.0','\n'.join(p.patterns))
        ttk.Label(dlg,text='Исключения: регулярные выражения (по одному на строку)',padding=(10,6)).pack(anchor='w')
        exclusions=tk.Text(dlg,height=4);exclusions.pack(fill='x',padx=10)
        exclusions.insert('1.0','\n'.join(p.exclude_regex))
        ttk.Label(dlg,text='Распознавание номера ячейки проходки (для справки)',padding=(10,6)).pack(anchor='w')
        penetration=tk.StringVar(value=p.penetration_pattern)
        ttk.Entry(dlg,textvariable=penetration).pack(fill='x',padx=10)
        ttk.Label(dlg,text='Подтверждённые постоянные замены, JSON (по умолчанию пусто)',padding=(10,6)).pack(anchor='w')
        rules=tk.Text(dlg,height=4);rules.pack(fill='x',padx=10);rules.insert('1.0',json.dumps(p.replacements,ensure_ascii=False))
        test=ttk.Frame(dlg,padding=10);test.pack(fill='x')
        sample=tk.StringVar(value='L1-42EM41A-SG01-WC01')
        ttk.Entry(test,textvariable=sample,width=47).pack(side='left')
        result=tk.StringVar(value='')
        def read_form():
            o=Profile(name=name.get().strip(),version=version.get().strip(),
                      patterns=[x.strip() for x in patterns.get('1.0','end').splitlines() if x.strip()],
                      exclude_regex=[x.strip() for x in exclusions.get('1.0','end').splitlines() if x.strip()],
                      penetration_pattern=penetration.get().strip(),
                      replacements=json.loads(rules.get('1.0','end').strip() or '{}'))
            if not o.name or '/' in o.name or '\\' in o.name or '..' in o.name:
                raise ValidationError('Некорректное имя профиля')
            return o.validate()
        def test_mask():
            try:
                import re
                o=read_form();result.set('НАЙДЕНО' if any(re.search(x,normalize(sample.get(),o),re.I) for x in o.patterns) else 'НЕ НАЙДЕНО')
            except Exception as exc:result.set('Ошибка: '+str(exc))
        ttk.Button(test,text='Проверить маску',command=test_mask).pack(side='left',padx=5)
        ttk.Label(dlg,textvariable=result).pack(anchor='w',padx=10)
        def save():
            try:
                o=read_form()
                path=profile_dir()/(o.name+'.json')
                if path.exists() and not messagebox.askyesno('Профиль','Заменить текущий профиль?',parent=dlg):return
                o.save(path);self.profile=o;self.profile_path=path;self.profile_var.set(o.name)
                self._refresh_profiles();dlg.destroy()
            except Exception as exc:messagebox.showerror('Профиль',str(exc),parent=dlg)
        ttk.Button(dlg,text='Сохранить профиль',command=save).pack(pady=9)

    def import_profile(self):
        f=filedialog.askopenfilename(filetypes=[('JSON','*.json')]);
        if not f:return
        try:
            p=Profile.load(Path(f));path=profile_dir()/(p.name+'.json')
            if path.exists() and not messagebox.askyesno('Профиль','Перезаписать имеющийся профиль?'):return
            p.save(path);self.profile_var.set(p.name);self._load_profile()
        except Exception as exc:messagebox.showerror('Импорт профиля',str(exc))

    def export_profile(self):
        f=filedialog.asksaveasfilename(defaultextension='.json',filetypes=[('JSON','*.json')],
                                      initialfile=self.profile.name+'.json')
        if f:
            try:self.profile.save(Path(f))
            except Exception as exc:messagebox.showerror('Экспорт профиля',str(exc))

    def export_dialog(self):
        if not self.session:messagebox.showinfo('Нет результатов','Сначала выполните сверку');return
        dlg=tk.Toplevel(self.root);dlg.title('Экспорт результатов');dlg.transient(self.root)
        ttk.Label(dlg,text='Выберите выходные файлы текущей сверки',padding=12).pack(anchor='w')
        options=[('Протокол Excel (.xlsx)','xlsx','СКП_протокол.xlsx'),
                 ('Цветной PDF потоков','flow','СКП_потоки_подсветка.pdf'),
                 ('Цветной PDF проходок','penetration','СКП_проходки_подсветка.pdf')]
        vars={key:tk.BooleanVar(value=True if key=='xlsx' else False) for _,key,_ in options}
        for label,key,_ in options:ttk.Checkbutton(dlg,text=label,variable=vars[key]).pack(anchor='w',padx=16,pady=5)
        folder=tk.StringVar(value=str(Path.home()/'Documents'))
        fr=ttk.Frame(dlg,padding=8);fr.pack()
        ttk.Entry(fr,textvariable=folder,width=55).pack(side='left')
        ttk.Button(fr,text='Папка…',command=lambda:self._folder_select(folder)).pack(side='left',padx=5)
        def run():
            choices=[(key,Path(folder.get())/name) for _,key,name in options if vars[key].get()]
            if not choices:messagebox.showwarning('Экспорт','Выберите хотя бы один файл',parent=dlg);return
            for key,path in choices:
                if path.exists() and not messagebox.askyesno('Файл существует',f'{path.name} уже существует. Перезаписать?',parent=dlg):return
                if path.resolve() in (Path(self.session.flows.path).resolve(),Path(self.session.penetrations.path).resolve()):
                    messagebox.showerror('Экспорт','Исходный PDF нельзя изменять',parent=dlg);return
            staged=[]
            try:
                # Prepare all outputs before replacing any existing report. Original PDFs remain untouched.
                for key,path in choices:
                    path.parent.mkdir(parents=True,exist_ok=True)
                    temp=path.with_name('.skp_new_'+__import__('uuid').uuid4().hex+path.suffix)
                    if key=='xlsx':save_xlsx(self.session,temp)
                    else:highlight_pdf(self.session,'Потоки' if key=='flow' else 'Проходки',temp)
                    staged.append((temp,path))
                for temp,path in staged: temp.replace(path)
                dlg.destroy();messagebox.showinfo('Экспорт завершён',
                    'Сохранены файлы:\n'+'\n'.join(str(path) for _,path in staged))
            except Exception as exc:messagebox.showerror('Экспорт',str(exc),parent=dlg)
            finally:
                for temp,_ in staged: temp.unlink(missing_ok=True)
        ttk.Button(dlg,text='Экспортировать',command=run).pack(pady=12)

    def _folder_select(self,var):
        d=filedialog.askdirectory()
        if d:var.set(d)

    def save_session_dialog(self):
        if not self.session:messagebox.showinfo('История','Сначала выполните сверку');return
        answer=messagebox.askyesnocancel('История',
             'Сохранить сеанс в истории?\n\nДа — вместе с копиями двух PDF.\nНет — только результаты и координаты.\nОтмена — не сохранять.')
        if answer is None:return
        try:
            path=save_session(self.session,copy_pdf=answer)
            messagebox.showinfo('История','Сеанс сохранён:\n'+str(path))
        except Exception as exc:messagebox.showerror('История',str(exc))

    def open_history(self):
        dlg=tk.Toplevel(self.root);dlg.title('История и сравнение ревизий');dlg.geometry('1020x480')
        tbl=ttk.Treeview(dlg,columns=['date','project','flow','pen','results'],show='headings',selectmode='extended')
        for c,label,w in [('date','Дата',175),('project','Проект',280),('flow','Рев. потоков',125),
                          ('pen','Рев. проходок',125),('results','Кабелей',95)]:
            tbl.heading(c,text=label);tbl.column(c,width=w)
        tbl.pack(fill='both',expand=True,padx=10,pady=10)
        paths={}
        for i,item in enumerate(list_sessions()):
            tbl.insert('','end',iid=str(i),values=(item['date'],item['project'],item['flow_rev'],item['pen_rev'],item['rows']))
            paths[str(i)]=Path(item['path'])
        def selected(count):
            ids=tbl.selection()
            if len(ids)!=count:messagebox.showwarning('История',f'Выберите {count} сеанс(а)',parent=dlg);return None
            return [load_session(paths[i]) for i in ids]
        def opening():
            arr=selected(1)
            if arr:
                self.session=arr[0];self.fill();self.project_var.set(arr[0].project);dlg.destroy()
        def comparing():
            arr=selected(2)
            if not arr:return
            diffs,warnings=revision_diff(*arr)
            screen=tk.Toplevel(dlg);screen.title('Сравнение ревизий');screen.geometry('980x590')
            txt=tk.Text(screen,wrap='none',font=('Consolas',10))
            txt.pack(fill='both',expand=True)
            txt.insert('end',f'Ревизии: {arr[0].flow_revision}/{arr[0].penetration_revision} → '
                             f'{arr[1].flow_revision}/{arr[1].penetration_revision}\n')
            for warn in warnings:txt.insert('end','ПРЕДУПРЕЖДЕНИЕ: '+warn+'\n')
            for cable,state,old,new in diffs:
                if state!='Без изменений':txt.insert('end',f'{state:38s} {cable}  ({old} → {new})\n')
            txt.config(state='disabled')
        fr=ttk.Frame(dlg);fr.pack(pady=7)
        ttk.Button(fr,text='Открыть сеанс',command=opening).pack(side='left',padx=6)
        ttk.Button(fr,text='Сравнить две ревизии',command=comparing).pack(side='left',padx=6)

    def reset(self):
        self.session=None;self.tree.delete(*self.tree.get_children())
        self.progress_var.set(0);self.summary_var.set('Новая сверка: укажите два PDF.')

    def on_close(self):
        if self.worker and self.worker.is_alive():
            if not messagebox.askyesno('Сверка идёт','Остановить проверку и выйти?'):return
            self.cancel_event.set()
        setting={'geometry':self.root.geometry(),'flow':self.flow_var.get(),'pen':self.pen_var.get(),
                 'project':self.project_var.get(),'columns':self.show_hidden,
                 'widths':{k:self.tree.column(k,'width') for k in COLUMNS}}
        try:write_settings(setting)
        except OSError:pass
        self.root.destroy()


def start():
    root=tk.Tk()
    # Icon file supplied by the user: embedded into EXE and taskbar.
    icon_candidates=[Path(getattr(sys,'_MEIPASS',''))/'CablePDFCompare.ico',
                     Path(__file__).resolve().parent/'CablePDFCompare.ico']
    for ico in icon_candidates:
        if ico.is_file():
            try:root.iconbitmap(str(ico));break
            except tk.TclError:pass
    SKPApp(root)
    root.mainloop()
