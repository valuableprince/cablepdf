# -*- coding: utf-8 -*-
"""CLI for reproducible engineering checks and automated acceptance tests."""
from pathlib import Path
from collections import Counter
import argparse
import sys

from skp_core import make_session,Profile,ValidationError,Cancelled
from skp_export import save_xlsx,highlight_pdf


def main():
    parser=argparse.ArgumentParser(description='СКП — text PDF comparison (without OCR)')
    parser.add_argument('--flows',required=True,type=Path,help='Контрольный перечень / кабельные потоки')
    parser.add_argument('--penetrations',required=True,type=Path,help='PDF кабельных проходок')
    parser.add_argument('--profile',type=Path)
    parser.add_argument('--xlsx',type=Path)
    parser.add_argument('--highlight-flows',type=Path)
    parser.add_argument('--highlight-penetrations',type=Path)
    parser.add_argument('--mode',choices=['Быстрая','Расширенная'],default='Быстрая')
    p=parser.parse_args()
    try:
        session=make_session(p.flows,p.penetrations,
                             profile=Profile.load(p.profile) if p.profile else Profile(),mode=p.mode)
        print('Результаты:',dict(Counter(x.status for x in session.rows)))
        print('Предупреждения:',len(session.issues))
        if p.xlsx: save_xlsx(session,p.xlsx);print('XLSX:',p.xlsx)
        if p.highlight_flows: print('PDF потоков:',highlight_pdf(session,'Потоки',p.highlight_flows)[0])
        if p.highlight_penetrations:print('PDF проходок:',highlight_pdf(session,'Проходки',p.highlight_penetrations)[0])
    except (ValidationError,Cancelled) as exc:
        print('Ошибка:',str(exc),file=sys.stderr);return 2
    return 0
if __name__=='__main__':sys.exit(main())
