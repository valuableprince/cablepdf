# -*- coding: utf-8 -*-
"""СКП: консервативная сверка двух текстовых PDF, без OCR и неявных замен букв."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from collections import defaultdict
from typing import Callable
import json
import re
import uuid

import fitz

VERSION = '0.8.0-beta'
DEFAULT_PATTERN = r'L[0-9]{1,3}-(?:[A-ZА-ЯЁ0-9]+-){1,24}W[CP][0-9]{2}'
DASHES = str.maketrans({'–':'-', '—':'-', '−':'-', '‑':'-', '‒':'-', '﹣':'-', '－':'-'})
# Warning only: never use these for equality.
CONFUSABLES = str.maketrans({'А':'A','В':'B','Е':'E','К':'K','М':'M','Н':'H','О':'O',
                               'Р':'P','С':'C','Т':'T','Х':'X','У':'Y','І':'I'})
BAD_RE = re.compile(r'\b(30/13-23|40/23-34|10/0-120|90/51-75|РЕЗЕРВ)\b',re.I)
START = re.compile(r'L\d{1,3}-',re.I)

class ValidationError(Exception):
    pass
class Cancelled(Exception):
    pass

@dataclass
class Profile:
    name: str = 'Стандартный'
    version: str = '1.0'
    patterns: list[str] = field(default_factory=lambda:[DEFAULT_PATTERN])
    exclude_regex: list[str] = field(default_factory=list)
    penetration_pattern: str = r'\b[12]\.\d{1,2}\.\d{1,2}\b'
    replacements: dict[str,str] = field(default_factory=dict) # ONLY explicitly user-confirmed
    min_text_chars: int = 3

    def validate(self):
        if len(self.patterns)>12 or len(self.exclude_regex)>30: raise ValidationError('Слишком много правил в профиле')
        for pat in self.patterns+self.exclude_regex+[self.penetration_pattern]:
            if len(pat)>280: raise ValidationError('Маска длиннее 280 символов')
            if re.search(r'\([^)]*[+*][^)]*\)[+*]',pat):
                raise ValidationError('Запрещено вложенное повторение квантификаторов в маске')
            try: re.compile(pat)
            except re.error as exc: raise ValidationError(f'Некорректная маска {pat}: {exc}') from exc
        if not self.patterns: raise ValidationError('Укажите хотя бы одну маску кабеля')
        if self.min_text_chars < 1: raise ValidationError('min_text_chars должен быть положительным')
        return self

    @staticmethod
    def load(path: Path) -> 'Profile':
        obj = json.loads(path.read_text(encoding='utf-8'))
        return Profile(**{k:v for k,v in obj.items() if k in Profile.__dataclass_fields__}).validate()

    def save(self, path: Path):
        self.validate(); path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(asdict(self),ensure_ascii=False,indent=2),encoding='utf-8')


def normalize(text: str, profile: Profile|None=None) -> str:
    """Only safe normalization from TZ §4.2: case, dash, surrounding whitespace."""
    s = text.upper().translate(DASHES)
    s = re.sub(r'\s*-\s*','-',s)
    s = s.strip()
    if profile and profile.replacements:
        # User-approved explicit rules, never automatic confusable transliteration.
        for src,dst in profile.replacements.items():
            s = s.replace(src.upper(),dst.upper())
    return s


def confusable_hint(text: str) -> str:
    return text.translate(CONFUSABLES)

@dataclass
class Occurrence:
    id: str
    role: str
    page: int
    raw: str
    key: str
    rect: list[float]
    direction: list[float]
    excluded: bool = False
    manual: str = ''
    penetration_id: str = ''
    evidence: str = ''
    verified_link: bool = False

@dataclass
class Issue:
    code: str
    role: str
    page: int
    occurrence_id: str
    text: str
    details: str

@dataclass
class DocumentData:
    role: str
    path: str
    filename: str
    digest: str
    page_count: int
    checked_pages: list[int]
    unchecked_pages: list[int]
    skipped_pages: list[int]
    occurrences: list[Occurrence]

@dataclass
class ComparisonRow:
    key: str
    status: str
    flow_pages: str
    penetration_pages: str
    flow_count: int
    penetration_count: int
    assignments: str
    link_quality: str
    note: str

@dataclass
class Session:
    sid: str
    created: str
    project: str
    flow_revision: str
    penetration_revision: str
    mode: str
    profile: Profile
    flows: DocumentData
    penetrations: DocumentData
    rows: list[ComparisonRow] = field(default_factory=list)
    issues: list[Issue] = field(default_factory=list)
    decisions: list[dict] = field(default_factory=list)

    def recalc(self):
        self.rows = compare(self)
        return self

    def to_dict(self): return asdict(self)

    @classmethod
    def from_dict(cls, data: dict):
        profile=Profile(**data['profile'])
        def load_doc(item):
            item=dict(item);item.pop('archived_pdf',None)
            item['occurrences']=[Occurrence(**x) for x in item.get('occurrences',[])]
            return DocumentData(**item)
        return cls(sid=data['sid'],created=data['created'],project=data.get('project',''),
                   flow_revision=data.get('flow_revision',''),penetration_revision=data.get('penetration_revision',''),
                   mode=data.get('mode','Быстрая'),profile=profile,flows=load_doc(data['flows']),
                   penetrations=load_doc(data['penetrations']),
                   rows=[ComparisonRow(**x) for x in data.get('rows',[])],
                   issues=[Issue(**x) for x in data.get('issues',[])],decisions=data.get('decisions',[]))


def compile_patterns(profile):
    profile.validate()
    return [re.compile(p,re.I) for p in profile.patterns], [re.compile(p,re.I) for p in profile.exclude_regex]


def extract_from_line(line, page_number, role, compiled, exceptions, profile):
    """Uses per-character geometry. Never concatenates PDF text across unrelated lines."""
    chars=[]
    for span in line.get('spans',[]):
        chars.extend(span.get('chars',[]))
    if not chars: return []
    s=''.join(x.get('c','') for x in chars)
    if len(s)>10000: return []  # pathological objects
    found=[]; seen=set()
    for pattern in compiled:
        for m in pattern.finditer(s):
            if (m.start(),m.end()) in seen: continue
            snippet=s[m.start():m.end()]
            # Ensure token not silently truncated (e.g. trailing 3rd digit after WC01).
            trailing=s[m.end():m.end()+1]
            if trailing and (trailing.isdigit() or trailing=='_'): continue
            if any(z.search(snippet) for z in exceptions): continue
            # Do not accept a marked substring in a concatenated identifier except "L1" start.
            if m.start() and (s[m.start()-1].isalnum() or s[m.start()-1]=='_'):continue
            bb=[c['bbox'] for c in chars[m.start():m.end()] if 'bbox' in c]
            if not bb: continue
            r=[min(a[0] for a in bb),min(a[1] for a in bb),max(a[2] for a in bb),max(a[3] for a in bb)]
            direction=list(line.get('dir',(1.0,0.0)))
            key=normalize(snippet,profile)
            seen.add((m.start(),m.end()))
            found.append(Occurrence(uuid.uuid4().hex,role,page_number,snippet,key,
                                    [round(v,3) for v in r],direction))
    return found


def digest_file(path: Path):
    h=sha256()
    with path.open('rb') as fd:
        for block in iter(lambda:fd.read(1024*1024),b''): h.update(block)
    return h.hexdigest()


def analyze_pdf(path: Path, role: str, profile: Profile, skip_pages: set[int]|None=None,
                progress:Callable|None=None, cancelled:Callable|None=None) -> tuple[DocumentData,list[Issue]]:
    path=Path(path)
    if not path.is_file() or path.suffix.lower()!='.pdf': raise ValidationError(f'Файл PDF не найден: {path}')
    skip=set(skip_pages or [])
    compiled, exclusions=compile_patterns(profile)
    occ=[]; issues=[]; checked=[]; unchecked=[]; skipped=[]
    try: pdf=fitz.open(path)
    except Exception as exc: raise ValidationError(f'Невозможно открыть PDF {path.name}: {exc}') from exc
    page_count = pdf.page_count
    with pdf:
        if pdf.needs_pass: raise ValidationError(f'Защищённый PDF: {path.name}')
        if pdf.page_count < 1: raise ValidationError(f'Пустой PDF: {path.name}')
        for i in range(pdf.page_count):
            if cancelled and cancelled(): raise Cancelled()
            number=i+1
            if number in skip:
                skipped.append(number); continue
            if progress: progress(role,number,pdf.page_count)
            page=pdf[i]
            try:
                text=page.get_text('text')
                if len(re.sub(r'\s','',text)) < profile.min_text_chars:
                    unchecked.append(number)
                    issues.append(Issue('WR-03',role,number,'','Нет извлекаемого текстового слоя',
                                        'Не объявлять отсутствующие кабели достоверной ошибкой'))
                    continue
                raw=page.get_text('rawdict')
                for block in raw['blocks']:
                    for line in block.get('lines',[]):
                        occ.extend(extract_from_line(line,number,role,compiled,exclusions,profile))
                checked.append(number)
            except Cancelled: raise
            except Exception as exc:
                unchecked.append(number)
                issues.append(Issue('WR-03',role,number,'',f'Ошибка извлечения: {exc}',
                                    'Невозможно утверждать полноту результата'))
        if not checked:
            raise ValidationError(f'{path.name}: нет ни одной проверяемой страницы с текстовым слоем')
    if not occ:
        issues.append(Issue('WR-01',role,0,'','Кабели по активной маске не обнаружены',
                            'Проверьте шаблоны и структуру PDF перед оценкой результатов'))
    for item in occ:
        if item.raw != confusable_hint(item.raw):
            issues.append(Issue('WR-01',role,item.page,item.id,item.raw,
                                'В маркировке есть кириллические двойники латинских букв; автоматической замены нет'))
    data=DocumentData(role,str(path.resolve()),path.name,digest_file(path),page_count,
                      checked,unchecked,sorted(skip),occ)
    return data,issues


def pages_str(occ): return ', '.join(map(str,sorted({o.page for o in occ})))


def compare(session: Session):
    flows=defaultdict(list); penetr=defaultdict(list)
    for occ in session.flows.occurrences:
        if not occ.excluded: flows[occ.key].append(occ)
    for occ in session.penetrations.occurrences:
        if not occ.excluded: penetr[occ.key].append(occ)
    # Only evidence-verified assignments can make conflicts; page-local names alone are insufficient.
    claims=defaultdict(set)
    for key,mentions in penetr.items():
        for o in mentions:
            if o.verified_link and o.penetration_id:
                claims[o.penetration_id].add(key)
    conflicts={key for _,keys in claims.items() if len(keys)>1 for key in keys}
    partial=bool(session.flows.unchecked_pages or session.penetrations.unchecked_pages or
                 not flows or not penetr)
    output=[]
    for key in sorted(flows.keys()|penetr.keys()):
        a,b=flows.get(key,[]),penetr.get(key,[])
        if key in conflicts: code='ER-03';note='Подтверждённый конфликт физической проходки'
        elif a and b:code='OK-01';note='Обозначение найдено в обоих PDF; привязка проверяется отдельно'
        elif partial:code='WR-03';note='Неполная проверка страниц: нельзя достоверно утверждать отсутствие'
        elif a:code='ER-01';note='Есть в потоках; отсутствует в проходках (не всегда ошибка проекта)'
        else:code='ER-02';note='Есть в проходках; отсутствует в потоках'
        links=sorted({o.penetration_id for o in b if o.verified_link and o.penetration_id})
        link_quality=('Подтверждена' if len(links)==len({o.penetration_id for o in b}) and
                      all(o.verified_link and o.penetration_id for o in b) and b
                      else 'WR-02: привязка не подтверждена' if b else '—')
        output.append(ComparisonRow(key,code,pages_str(a),pages_str(b),len(a),len(b),
                                    ', '.join(links),link_quality,note))
    order={'ER-03':0,'ER-01':1,'ER-02':2,'WR-03':3,'OK-01':4}
    return sorted(output,key=lambda x:(order.get(x.status,8),x.key))


def make_session(flows:Path, penetrations:Path, profile:Profile|None=None,
                 mode='Быстрая',project='',flow_revision='',penetration_revision='',
                 skip_flow=None,skip_penetrations=None,progress=None,cancelled=None)->Session:
    if Path(flows).resolve()==Path(penetrations).resolve():raise ValidationError('Два входных PDF должны быть разными файлами')
    profile=profile or Profile()
    a,issues_a=analyze_pdf(Path(flows),'Потоки',profile,set(skip_flow or []),progress,cancelled)
    b,issues_b=analyze_pdf(Path(penetrations),'Проходки',profile,set(skip_penetrations or []),progress,cancelled)
    return Session(uuid.uuid4().hex,datetime.now().isoformat(timespec='seconds'),project,
                   flow_revision,penetration_revision,mode,profile,a,b,issues=issues_a+issues_b).recalc()


def apply_decision(session:Session, occurrence_id:str, action:str,value='',comment=''):
    item=next((x for d in (session.flows,session.penetrations) for x in d.occurrences if x.id==occurrence_id),None)
    if not item: raise ValidationError('Упоминание отсутствует в сеансе')
    before={'raw':item.raw,'key':item.key,'excluded':item.excluded,'penetration_id':item.penetration_id,
            'verified_link':item.verified_link}
    if action=='исправить':
        if not value.strip():raise ValidationError('Укажите исправленное обозначение')
        valid=any(re.fullmatch(p,normalize(value,session.profile),re.I) for p in session.profile.patterns)
        if not valid:raise ValidationError('Исправление не соответствует активным маскам кабеля')
        item.key=normalize(value,session.profile);item.manual=value.strip();item.excluded=False
    elif action=='исключить':item.excluded=True
    elif action=='подтвердить':item.excluded=False
    elif action=='привязать':
        if item.role!='Проходки':raise ValidationError('Привязку к проходке задают со стороны проходок')
        if not value.strip():raise ValidationError('Укажите уникальный идентификатор физической проходки')
        item.penetration_id=value.strip(); item.verified_link=True
    elif action=='снять привязку':item.penetration_id='';item.verified_link=False
    else:raise ValidationError(f'Неизвестное решение: {action}')
    session.decisions.append({'timestamp':datetime.now().isoformat(timespec='seconds'),
                              'occurrence_id':occurrence_id,'action':action,'before':before,
                              'after':{'key':item.key,'excluded':item.excluded,'penetration_id':item.penetration_id,
                                       'verified_link':item.verified_link},'comment':comment})
    session.recalc()


def revision_diff(first:Session,second:Session):
    a={r.key:r for r in first.rows};b={r.key:r for r in second.rows}
    result=[]
    for k in sorted(a.keys()|b.keys()):
        if k not in a:state='Добавлен кабель'
        elif k not in b:state='Удалён кабель'
        elif a[k].status!=b[k].status:state='Изменился статус / замечание'
        elif a[k].assignments!=b[k].assignments:state='Изменилась привязка'
        else:state='Без изменений'
        result.append((k,state,a[k].status if k in a else '',b[k].status if k in b else ''))
    warnings=[]
    if asdict(first.profile)!=asdict(second.profile):warnings.append('Разные профили: сопоставимость ограничена')
    if any(d.unchecked_pages for d in (first.flows,first.penetrations,second.flows,second.penetrations)):
        warnings.append('Есть непроверенные страницы; итог сравнения ревизий ограничен')
    return result,warnings
