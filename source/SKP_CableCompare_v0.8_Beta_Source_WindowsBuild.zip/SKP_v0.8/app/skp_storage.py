# -*- coding: utf-8 -*-
"""Local profiles, settings and opt-in session archives (no network)."""
from pathlib import Path
from datetime import datetime
import json
import os
import shutil
import zipfile

from skp_core import Session,Profile,ValidationError,revision_diff


def user_dir() -> Path:
    root=os.environ.get('LOCALAPPDATA') if os.name=='nt' else os.environ.get('XDG_CONFIG_HOME')
    if root:return Path(root)/'SKP_CableCompare'
    return Path.home()/'.config'/'SKP_CableCompare'


def settings_path():return user_dir()/'settings.json'

def read_settings()->dict:
    try:return json.loads(settings_path().read_text(encoding='utf-8'))
    except (FileNotFoundError,ValueError,OSError):return {}

def write_settings(x:dict):
    loc=settings_path();loc.parent.mkdir(parents=True,exist_ok=True)
    tmp=loc.with_suffix('.tmp');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(loc)

def profile_dir()->Path:
    folder=user_dir()/'profiles'; folder.mkdir(parents=True,exist_ok=True)
    return folder

def list_profiles()->list[Path]:return sorted(profile_dir().glob('*.json'))

def history_dir()->Path:
    folder=user_dir()/'history';folder.mkdir(parents=True,exist_ok=True)
    return folder

def save_session(session:Session,copy_pdf=False)->Path:
    """Session archive is only created after explicit user action."""
    dest=history_dir()/f"{session.created[:10]}_{session.sid[:8]}.zip"
    if dest.exists():raise ValidationError('Сеанс уже существует')
    payload=session.to_dict()
    # Copies are opt-in and source PDFs are never modified.
    files=[]
    if copy_pdf:
        for key in ('flows','penetrations'):
            path=Path(payload[key]['path'])
            if not path.is_file():raise ValidationError(f'Исходный PDF недоступен: {path}')
            if path.stat().st_size>200*1024*1024:
                raise ValidationError('PDF больше 200 МБ; для архива с копиями отключите соответствующую опцию')
            files.append((key,path))
    dest.parent.mkdir(parents=True,exist_ok=True)
    tmp=dest.with_suffix('.tmp')
    try:
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
            for role,path in files:
                saved_name=f'PDF/{role}.pdf'
                archive.write(path,saved_name)
                payload[role]['archived_pdf']=saved_name
            archive.writestr('session.json',json.dumps(payload,ensure_ascii=False,indent=2))
        tmp.replace(dest)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise
    return dest

def load_session(path:Path,extract_pdf:bool=True)->Session:
    path=Path(path)
    with zipfile.ZipFile(path) as z:
        data=json.loads(z.read('session.json'))
        s=Session.from_dict(data)
        if extract_pdf:
            folder=user_dir()/'session_pdf_cache'/s.sid
            for key,doc in (('flows',s.flows),('penetrations',s.penetrations)):
                original=Path(doc.path)
                if original.is_file():continue
                archived=data[key].get('archived_pdf')
                if archived and archived in z.namelist():
                    folder.mkdir(parents=True,exist_ok=True)
                    target=folder/f'{key}.pdf'
                    if not target.is_file():
                        with z.open(archived) as src,target.open('wb') as dst:
                            shutil.copyfileobj(src,dst)
                    doc.path=str(target)
        return s

def list_sessions():
    rows=[]
    for p in sorted(history_dir().glob('*.zip'),reverse=True):
        try:
            with zipfile.ZipFile(p) as z:
                s=json.loads(z.read('session.json'))
            rows.append({'path':str(p),'id':s['sid'],'date':s['created'],
                         'project':s.get('project',''), 'flow_rev':s.get('flow_revision',''),
                         'pen_rev':s.get('penetration_revision',''),
                         'rows':len(s.get('rows',[]))})
        except (ValueError, KeyError, zipfile.BadZipFile):continue
    return rows
