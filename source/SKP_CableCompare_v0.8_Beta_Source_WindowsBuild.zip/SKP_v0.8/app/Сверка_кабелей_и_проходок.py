# -*- coding: utf-8 -*-
from skp_gui import start
if __name__ == '__main__':
    start()
