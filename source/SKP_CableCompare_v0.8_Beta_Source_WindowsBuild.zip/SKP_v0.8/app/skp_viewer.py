# -*- coding: utf-8 -*-
"""Non-modal PDF viewer with real page rendering, scale, paging, and source coordinates."""
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox
import fitz
from PIL import Image,ImageTk

class PDFViewer(tk.Toplevel):
    def __init__(self,master,session,role='Потоки',occurrence=None):
        super().__init__(master)
        self.session=session
        self.title('СКП — просмотр текстовых PDF')
        self.geometry('1200x780'); self.minsize(640,420)
        self.role=tk.StringVar(value=role)
        self.page_number=tk.IntVar(value=occurrence.page if occurrence else 1)
        self.scale=1.0
        self.fit=True
        self.occurrence=occurrence
        self.doc=None;self.photo=None;self._pending=False
        self.protocol('WM_DELETE_WINDOW',self.close)
        top=ttk.Frame(self,padding=6);top.pack(fill='x')
        ttk.Label(top,text='PDF:').pack(side='left')
        switch=ttk.Combobox(top,textvariable=self.role,values=['Потоки','Проходки'],state='readonly',width=12)
        switch.pack(side='left',padx=(4,10));switch.bind('<<ComboboxSelected>>',lambda _:self.switch_pdf())
        ttk.Button(top,text='◀',width=3,command=self.previous).pack(side='left')
        self.label=ttk.Label(top,text='1 / 1',width=12,anchor='center');self.label.pack(side='left')
        ttk.Button(top,text='▶',width=3,command=self.next).pack(side='left',padx=(0,12))
        ttk.Button(top,text='−',width=3,command=lambda:self.zoom(.8)).pack(side='left')
        ttk.Button(top,text='+',width=3,command=lambda:self.zoom(1.25)).pack(side='left')
        ttk.Button(top,text='По ширине',command=self.zoom_fit).pack(side='left',padx=6)
        self.loclabel=ttk.Label(top,text='');self.loclabel.pack(side='left',padx=12)
        frame=ttk.Frame(self);frame.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(frame,bg='#555e66',highlightthickness=0)
        scroll_y=ttk.Scrollbar(frame,orient='vertical',command=self.canvas.yview)
        scroll_x=ttk.Scrollbar(frame,orient='horizontal',command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=scroll_y.set,xscrollcommand=scroll_x.set)
        self.canvas.grid(row=0,column=0,sticky='nsew');scroll_y.grid(row=0,column=1,sticky='ns')
        scroll_x.grid(row=1,column=0,sticky='ew');frame.columnconfigure(0,weight=1);frame.rowconfigure(0,weight=1)
        self.canvas.bind('<Control-MouseWheel>',lambda e:self.zoom(1.2 if e.delta>0 else .83))
        self.bind('<Prior>',lambda e:self.previous());self.bind('<Next>',lambda e:self.next())
        self.canvas.bind('<Configure>',lambda e:self.scheduled_render() if self.fit else None)
        self.switch_pdf()

    def close(self):
        if self.doc:self.doc.close()
        self.destroy()

    def current_data(self):
        return self.session.flows if self.role.get()=='Потоки' else self.session.penetrations

    def switch_pdf(self):
        if self.doc: self.doc.close();self.doc=None
        target=Path(self.current_data().path)
        if not target.is_file():
            messagebox.showwarning('PDF недоступен',f'Исходный документ не найден:\n{target}',parent=self)
            return
        try:self.doc=fitz.open(target)
        except Exception as exc:
            messagebox.showerror('PDF',str(exc),parent=self);return
        self.page_number.set(min(max(1,self.page_number.get()),self.doc.page_count));self.zoom_fit()

    def scheduled_render(self):
        if not self._pending:
            self._pending=True
            self.after(100,self._render_if_pending)
    def _render_if_pending(self):
        self._pending=False;self.render()

    def zoom_fit(self):self.fit=True;self.render()
    def zoom(self,multiplier):
        self.fit=False;self.scale=min(4.0,max(.14,self.scale*multiplier));self.render()
    def previous(self):
        if self.doc and self.page_number.get()>1:self.page_number.set(self.page_number.get()-1);self.render()
    def next(self):
        if self.doc and self.page_number.get()<self.doc.page_count:
            self.page_number.set(self.page_number.get()+1);self.render()

    def jump_to(self,role,occurrence):
        if role != self.role.get():self.role.set(role);self.switch_pdf()
        if occurrence:
            self.occurrence=occurrence
            self.page_number.set(occurrence.page)
        self.render(scroll_to=True)

    def render(self,scroll_to=False):
        if not self.doc:return
        page=self.doc[self.page_number.get()-1]
        if self.fit:
            cw=max(200,self.canvas.winfo_width()-30)
            ch=max(200,self.canvas.winfo_height()-30)
            self.scale=min(cw/page.rect.width,ch/page.rect.height,2.0)
        scale=self.scale
        # Prevent huge A0 drawings from allocating unbounded memory.
        if page.rect.width*page.rect.height*scale*scale>14_000_000:
            scale=(14_000_000/(page.rect.width*page.rect.height))**.5
            self.scale=scale
        pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False)
        image=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
        self.photo=ImageTk.PhotoImage(image)
        self.canvas.delete('all')
        self.canvas.create_image(0,0,anchor='nw',image=self.photo)
        self.canvas.config(scrollregion=(0,0,pix.width,pix.height))
        self.label.config(text=f'{self.page_number.get()} / {self.doc.page_count}')
        self.loclabel.config(text=f'{self.current_data().filename}  •  {scale*100:.0f}%')
        if self.occurrence and self.occurrence.page==self.page_number.get() and self.occurrence.role==self.role.get():
            # PyMuPDF text geometry is in unrotated page coordinates.
            # Rotate before mapping into the displayed bitmap.
            region=fitz.Rect(self.occurrence.rect)*page.rotation_matrix
            region=region*fitz.Matrix(scale,scale)
            self.canvas.create_rectangle(*region,outline='#f4a900',width=3)
            if scroll_to:
                cx=(region.x0+region.x1)/2; cy=(region.y0+region.y1)/2
                self.canvas.xview_moveto(max(0,min(1,(cx-self.canvas.winfo_width()/2)/max(1,pix.width))))
                self.canvas.yview_moveto(max(0,min(1,(cy-self.canvas.winfo_height()/2)/max(1,pix.height))))
