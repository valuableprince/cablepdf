@echo off
cd /d "%~dp0"
py -3 app\Сверка_кабелей_и_проходок.py
pause
